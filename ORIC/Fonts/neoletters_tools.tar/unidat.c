#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "unidat.h"

int unidat_fd;
void *unidat;
const char **uni_names;

struct eaw_entry {
	int lb; // lower bound
	int ub; // upper bound
	int w;  // effective width
};

int eawdat_n;
struct eaw_entry *eawdat;

int load_eawdat() {
	FILE *eawdat_f = fopen("EastAsianWidth.txt","r");
	if (eawdat_f == NULL) return 1;
	char line[200];
	eawdat = malloc(sizeof(struct eaw_entry)*3000);
	int i = 0;
	int lb,ub;
	char wc;
	while (fgets(line,200,eawdat_f)) {
		if(line[0] == '#' || line[0] == '\n')continue;
		int j = 4;
		while(line[j] >= '0' && line[j] <= '9' || line[j] >= 'A' && line[j] <= 'F')j++;
		if(line[j] == ';'){
			if (2 != sscanf(line,"%x;%c",&lb,&wc)){
				printf("failed! %s\n",line);
                                abort();
			};
			eawdat[i].lb = lb;
			eawdat[i].ub = lb;
			eawdat[i].w = 1 + (wc == 'F' || wc == 'W');
		}
		if(line[j] == '.'){
			if (3 != sscanf(line,"%x..%x;%c",&lb,&ub,&wc)){
				printf("failed! %s\n",line);
				abort();
			}
			eawdat[i].lb = lb;
			eawdat[i].ub = ub;
			eawdat[i].w = 1 + (wc == 'F' || wc == 'W');
		}
		//printf("%d %x %x %d\n",i,eawdat[i].lb, eawdat[i].ub, eawdat[i].w);
		i++;
	}
	eawdat_n = i;
	fclose(eawdat_f);
	return i == 0;
}

int get_eaw(unsigned ch_u) {
	int ch = ch_u;
	int i = eawdat_n/2;
	int t = eawdat_n;
	int b = -1;
	while (1) {
		if (i == t || i == b)return 1;
		if (ch > eawdat[i].ub) {
			b = i;
			i = (i + t)/2;
		} else if (ch < eawdat[i].lb) {
			t = i;
			i = (i + b)/2;
		} else {
			return eawdat[i].w;
		}
	}
}

int unload_eawdat() {
	free(eawdat);
	eawdat_n = 0;
	return 0;
}

int load_unidat() {
	unidat_fd = open("UnicodeData.txt",O_RDONLY);
	if(unidat_fd == -1)return 1;
	off_t end = lseek(unidat_fd, 0, SEEK_END);
	unidat = mmap(NULL, end, PROT_READ, MAP_SHARED, unidat_fd, 0);
	if(unidat == MAP_FAILED){
		close(unidat_fd);
		return 1;
	}
	uni_names = (void*)calloc(0x20000,sizeof(char*));
	const char *base = unidat;
	const char *s = base;
	while(1){
		int c = 0;
		while(*s >= '0' && *s <= '9' || *s >= 'A' && *s <= 'F') {
			if(*s >= '0' && *s <= '9') c = c*16 + *s-'0';
			if(*s >= 'A' && *s <= 'F') c = c*16 + *s-'A'+10;
			s++;
		}
		if(c >= 0x20000)break;
		if(s >= base + end)break;
		s++;
		uni_names[c] = s;
		while(*s != '\n')s++;
		s++;
	}
	return 0;
}

const char *get_unidat_entry(unsigned ch) {
	if (ch >= 0x20000) return "over_name_limit\n";
	return uni_names[ch];
}

int unload_unidat() {
        free(uni_names);
	off_t end = lseek(unidat_fd, 0, SEEK_END);
	munmap(unidat,end);
        close(unidat_fd);
	return 0;
}


