int u8sscanch(const char *s,const char **end);
char *u8chtostr(unsigned ch);
int u8fputch(FILE *f, unsigned ch);
int u8putch(unsigned ch);
int u8fscanch(FILE *f);
int u8sscanch(const char *s,const char **end);
int u8scanch(void);
int u8chrwid(unsigned ch);
int u8chrwidn(unsigned ch);
