int load_unidat();
const char *get_unidat_entry(unsigned ch);
int unload_unidat();

int load_eawdat();
int get_eaw(unsigned ch);
int unload_eawdat();

